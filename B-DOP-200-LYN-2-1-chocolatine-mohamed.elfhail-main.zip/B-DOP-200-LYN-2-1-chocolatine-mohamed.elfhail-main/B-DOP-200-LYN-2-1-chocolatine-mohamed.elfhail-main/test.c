/*
** EPITECH PROJECT, 2026
** Mohamed El Fhail
** File description:
** test
*/

int main(void)
{
    return 0;
}